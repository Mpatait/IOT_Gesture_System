import tkinter as tk
import keyboard
import time
import serial

# -----------------------
# Config / Profiles
# -----------------------
profiles = {
    "Media Controls": {"sensor1_key": "volume up", "sensor2_key": "volume down"},
    "Profile 1": {"sensor1_key": "up", "sensor2_key": "down"},
}
current_profile = "Media Controls"

# debounce / timing trackers
last_play_pause_time = 0
last_volume_change_time = 0
last_navigation_time = 0

# -----------------------
# Tk root + variables
# -----------------------
root = tk.Tk()
root.title("Virtual Sensor Input")

sensor1_enabled = tk.BooleanVar(value=False)
sensor2_enabled = tk.BooleanVar(value=False)
both_sensors_enabled = tk.BooleanVar(value=True)

# -----------------------
# Serial connection (robust)
# -----------------------
arduino_port = "COM3"  # replace with your port (e.g., '/dev/ttyUSB0' on Linux)
baud_rate = 9600
ser = None
try:
    ser = serial.Serial(arduino_port, baud_rate, timeout=1)
except Exception as e:
    print(f"[Warning] Could not open serial port {arduino_port}: {e}")
    ser = None

# -----------------------
# Moving average helper
# -----------------------
sensor1_history = []
sensor2_history = []
max_history_size = 5
threshold = 1


def moving_average(sensor_history, new_value):
    """Append new_value, keep last max_history_size items, return average."""
    try:
        val = float(new_value)
    except Exception:
        val = 20.0
    sensor_history.append(val)
    if len(sensor_history) > max_history_size:
        sensor_history.pop(0)
    return sum(sensor_history) / len(sensor_history)


# -----------------------
# Processing & mapping sensors -> keyboard
# -----------------------
def process_sensor_data(sensor1, sensor2):
    global last_play_pause_time, last_volume_change_time, last_navigation_time

    profile = profiles.get(current_profile, {})
    sensor1_key = profile.get("sensor1_key", "")
    sensor2_key = profile.get("sensor2_key", "")
    current_time = time.time()

    # update sliders if they exist (they are created later, so guard access)
    try:
        if abs(sensor1_slider.get() - sensor1) > threshold:
            sensor1_slider.set(int(sensor1))
        if abs(sensor2_slider.get() - sensor2) > threshold:
            sensor2_slider.set(int(sensor2))
    except Exception:
        pass

    # Only act if both-sensors mode is enabled
    if not both_sensors_enabled.get():
        return

    if current_profile == "Media Controls":
        # Play/Pause if both sensors are very close (hand over both)
        if sensor1 < 10 and sensor2 < 10:
            if current_time - last_play_pause_time > 2:
                try:
                    keyboard.press_and_release("space")  # play/pause
                except Exception as e:
                    print(f"[keyboard] play/pause failed: {e}")
                last_play_pause_time = current_time
                print("Play/Pause triggered")
            return

        # Volume control with sensor1
        if sensor1_enabled.get():
            if sensor1 <= 3:
                if current_time - last_volume_change_time > 0.1:
                    try:
                        keyboard.press_and_release("volume down")
                    except Exception as e:
                        print(f"[keyboard] volume down failed: {e}")
                    last_volume_change_time = current_time
                    print("Volume Down triggered (fast)")
            elif 4 <= sensor1 <= 10:
                if current_time - last_volume_change_time > 0.25:
                    try:
                        keyboard.press_and_release("volume down")
                    except Exception as e:
                        print(f"[keyboard] volume down failed: {e}")
                    last_volume_change_time = current_time
                    print("Volume Down triggered (normal)")
            elif 11 <= sensor1 <= 20:
                if current_time - last_volume_change_time > 0.2:
                    try:
                        keyboard.press_and_release("volume up")
                    except Exception as e:
                        print(f"[keyboard] volume up failed: {e}")
                    last_volume_change_time = current_time
                    print("Volume Up triggered")

        # Navigation with sensor2
        if sensor2_enabled.get():
            if sensor2 < 10:
                if current_time - last_navigation_time > 0.5:
                    try:
                        keyboard.press_and_release("left")
                    except Exception as e:
                        print(f"[keyboard] left arrow failed: {e}")
                    last_navigation_time = current_time
                    print("Backward (left arrow) triggered")
            elif 11 <= sensor2 <= 20:
                if current_time - last_navigation_time > 0.5:
                    try:
                        keyboard.press_and_release("right")
                    except Exception as e:
                        print(f"[keyboard] right arrow failed: {e}")
                    last_navigation_time = current_time
                    print("Forward (right arrow) triggered")

    # Debug print for visibility
    print(f"Sensor1: {sensor1:.1f}, Sensor2: {sensor2:.1f} | Keys: {sensor1_key}, {sensor2_key}")


# -----------------------
# Read Arduino safely
# -----------------------
def read_from_arduino():
    """Return tuple (sensor1, sensor2). If serial not available or parse fails, return defaults."""
    if ser is None:
        return 20, 20
    try:
        if ser.in_waiting > 0:
            data = ser.readline().decode("utf-8").strip()
            parts = data.split(",")
            if len(parts) >= 2:
                s1 = int(float(parts[0].strip()))
                s2 = int(float(parts[1].strip()))
                return s1, s2
    except Exception as e:
        print(f"[serial read] error: {e}")
    return 20, 20


# -----------------------
# Update loop
# -----------------------
def update_sensors():
    if both_sensors_enabled.get():
        sensor1_value, sensor2_value = read_from_arduino()
        averaged_sensor1 = moving_average(sensor1_history, sensor1_value)
        averaged_sensor2 = moving_average(sensor2_history, sensor2_value)

        if not sensor1_enabled.get():
            averaged_sensor1 = 20
        if not sensor2_enabled.get():
            averaged_sensor2 = 20

        process_sensor_data(averaged_sensor1, averaged_sensor2)

    root.after(100, update_sensors)


# -----------------------
# UI: key binding window
# -----------------------
def open_key_binding_window():
    def save_key_bindings():
        s1 = sensor1_key_entry.get().strip()
        s2 = sensor2_key_entry.get().strip()
        profiles[current_profile]["sensor1_key"] = s1
        profiles[current_profile]["sensor2_key"] = s2
        key_binding_window.destroy()

    key_binding_window = tk.Toplevel(root)
    key_binding_window.title("Customize Key Bindings")
    window_width = 400
    window_height = 300
    key_binding_window.geometry(f"{window_width}x{window_height}")
    key_binding_window.update_idletasks()
    screen_width = key_binding_window.winfo_screenwidth()
    screen_height = key_binding_window.winfo_screenheight()
    position_x = (screen_width // 2) - (window_width // 2)
    position_y = (screen_height // 2) - (window_height // 2)
    key_binding_window.geometry(f"{window_width}x{window_height}+{position_x}+{position_y}")

    tk.Label(key_binding_window, text=f"Customizing Profile: {current_profile}").pack(pady=10)
    tk.Label(key_binding_window, text="Sensor 1 Key Binding:").pack(pady=5)
    sensor1_key_entry = tk.Entry(key_binding_window)
    sensor1_key_entry.insert(0, profiles[current_profile]["sensor1_key"])
    sensor1_key_entry.pack(pady=5)

    tk.Label(key_binding_window, text="Sensor 2 Key Binding:").pack(pady=5)
    sensor2_key_entry = tk.Entry(key_binding_window)
    sensor2_key_entry.insert(0, profiles[current_profile]["sensor2_key"])
    sensor2_key_entry.pack(pady=5)

    save_button = tk.Button(key_binding_window, text="Save", command=save_key_bindings)
    save_button.pack(pady=20)


# -----------------------
# Profile change handler
# -----------------------
def change_profile(new_profile):
    global current_profile
    if new_profile in profiles:
        current_profile = new_profile
        profile_label.config(text=f"Current Profile: {current_profile}")


# -----------------------
# Build main UI
# -----------------------
tk.Label(root, text="Sensor 1").pack()
sensor1_slider = tk.Scale(root, from_=0, to=20, orient="horizontal")
sensor1_slider.pack()
sensor1_switch = tk.Checkbutton(root, text="Enable Sensor 1", variable=sensor1_enabled)
sensor1_switch.pack()

tk.Label(root, text="Sensor 2").pack()
sensor2_slider = tk.Scale(root, from_=0, to=20, orient="horizontal")
sensor2_slider.pack()
sensor2_switch = tk.Checkbutton(root, text="Enable Sensor 2", variable=sensor2_enabled)
sensor2_switch.pack()

both_sensors_switch = tk.Checkbutton(root, text="Enable Both Sensors", variable=both_sensors_enabled)
both_sensors_switch.pack()

tk.Label(root, text="Select Profile").pack()
profile_var = tk.StringVar(value="Media Controls")
profile_dropdown = tk.OptionMenu(root, profile_var, *profiles.keys(), command=change_profile)
profile_dropdown.pack()

profile_label = tk.Label(root, text=f"Current Profile: {current_profile}")
profile_label.pack()

customize_button = tk.Button(root, text="Customize Key Bindings", command=open_key_binding_window)
customize_button.pack()

# start update loop and mainloop
update_sensors()
root.mainloop()
